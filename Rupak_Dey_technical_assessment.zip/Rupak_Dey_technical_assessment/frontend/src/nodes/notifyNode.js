// notifyNode.js
// send notifications based on certain conditions

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const NotifyNode = ({ id }) => {
  const [message, setMessage] = useState('');

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Notify"
      hasSource={false}
      sourceId={null}
      hasTarget={true}
      targetIds={[`${id}-notification`]}
    >
      <div>
        <label>
          Message: <br />
          <input 
            type="text" 
            value={message} 
            onChange={handleMessageChange} 
            className='input-text-style'
          />
        </label>
      </div>
    </BaseNode>
  );
}
