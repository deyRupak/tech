// sortNode.js
// sort a list of items

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const SortNode = ({ id }) => {
  const [sortOrder, setSortOrder] = useState('ascending');

  const handleOrderChange = (e) => {
    setSortOrder(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Sort"
      hasSource={true}
      sourceId={`${id}-sorted`}
      hasTarget={true}
      targetIds={[`${id}-sortedIn`]}
    >
      <div>
        <label>
          Order:
          <select value={sortOrder} onChange={handleOrderChange} className='select-dropdown'>
            <option value="ascending">Ascending</option>
            <option value="descending">Descending</option>
          </select>
        </label>
      </div>
    </BaseNode>
  );
}
