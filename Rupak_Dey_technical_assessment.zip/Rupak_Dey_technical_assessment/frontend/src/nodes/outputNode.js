// outputNode.js

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const OutputNode = ({ id, data }) => {
  const [currName, setCurrName] = useState(data?.outputName || id.replace('customOutput-', 'output_'));
  const [outputType, setOutputType] = useState(data.outputType || 'Text');

  const handleNameChange = (e) => {
    setCurrName(e.target.value);
  };

  const handleTypeChange = (e) => {
    setOutputType(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Output"
      hasSource={false}
      sourceId={null}
      hasTarget={true}
      targetIds={[`${id}-value`]}
    >
      <div>
        <label>
          Name: <br />
          <input 
            type="text" 
            value={currName} 
            onChange={handleNameChange} 
            className='input-text-style'
          />
        </label>
        <label>
          Type: <br />
          <select value={outputType} onChange={handleTypeChange} className='select-dropdown'>
            <option value="Text">Text</option>
            <option value="File">Image</option>
          </select>
        </label>
      </div>
    </BaseNode>
  );
}
