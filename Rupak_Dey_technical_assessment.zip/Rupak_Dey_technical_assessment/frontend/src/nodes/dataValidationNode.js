// dataValidationNode.js
// validate data against defined rules

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const DataValidationNode = ({ id }) => {
  const [validationRules, setValidationRules] = useState('');

  const handleRulesChange = (e) => {
    setValidationRules(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Data Validation"
      hasSource={true}
      sourceId={`${id}-validated`}
      hasTarget={false}
      targetIds={[]}
    >
      <div>
        <label>
          Validation Rules: <br />
          <input 
            type="text" 
            value={validationRules} 
            onChange={handleRulesChange} 
            className='input-text-style'
          />
        </label>
      </div>
    </BaseNode>
  );
}
