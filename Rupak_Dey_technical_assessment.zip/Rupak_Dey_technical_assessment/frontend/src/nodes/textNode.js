// textNode.js

import { useState, useEffect } from 'react';
import { Handle, Position, useUpdateNodeInternals } from 'reactflow';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const TextNode = ({ id, data }) => {
  const [currText, setCurrText] = useState(data?.text || '');
  const [variables, setVariables] = useState([]);
  const updateNodeInternals = useUpdateNodeInternals();

  const handleTextChange = (e) => {
    const text = e.target.value;
    setCurrText(text);

    // extracting variables from text input
    const regex = /{{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*}}/g;
    const matches = [];
    let match;

    while ((match = regex.exec(text)) !== null) {
      matches.push(match[1]); // variable names
    }
    
    setVariables(matches);
    updateNodeInternals(id);
  };

  const autoResizeTextArea = (e) => {
    const textarea = e.target;
    textarea.style.height = 'auto'; 
    textarea.style.height = `${textarea.scrollHeight}px`;
  };

  return (
    <BaseNode 
      id={id}
      title="Text"
      hasSource={true}
      sourceId={`${id}-output`}
    >
      <div>
        <label>
          <textarea 
            value={currText} 
            onChange={handleTextChange}
            onInput={(e) => autoResizeTextArea(e)}
            className='input-text-area-style'
          />
        </label>
      </div>
      {variables.map((variable, index) => (
        <Handle
          key={index}
          type="target"
          position={Position.Left}
          id={`${id}-${variable}`}
          style={{ top: `${(index + 1) * (100 / (variables.length + 1))}%` }}
        >
          <span style={{ position:'absolute', right: '1rem' }}>{variable}</span>
        </Handle>
      ))}
    </BaseNode>
  );
}

