// conditionNode.js
// evaluate a condition and branch the flow based on the result

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const ConditionNode = ({ id }) => {
  const [condition, setCondition] = useState('');

  const handleConditionChange = (e) => {
    setCondition(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Condition"
      hasSource={true}
      sourceId={`${id}-true`}
      hasTarget={true}
      targetIds={[`${id}-false`]}
    >
      <div>
        <label>
          <input 
            type="text" 
            value={condition} 
            onChange={handleConditionChange} 
            className='input-text-style'
          />
        </label>
      </div>
    </BaseNode>
  );
}
