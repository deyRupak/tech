// BaseNode.js

import { Handle, Position } from 'reactflow';
import './nodes.css';

export const BaseNode = ({ id, title, children, hasSource, hasTarget, sourceId, targetIds }) => {
  
  return (
    <div className='base-node'>
      <div style={{marginBottom: '1rem'}}>
        <span >{title}</span>
      </div>
      {children}
      {hasTarget && targetIds.map(targetId => (
        <Handle
          key={targetId}
          type="target"
          position={Position.Left}
          id={targetId}
        />
      ))}
      {hasSource && (
        <Handle
          type="source"
          position={Position.Right}
          id={sourceId}
        />
      )}
    </div>
  );
};
