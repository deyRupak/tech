// mapNode.js
// map input values to output values

import { useState } from 'react';
import { BaseNode } from './BaseNode';
import './nodes.css';

export const MapNode = ({ id }) => {
  const [mapConfig, setMapConfig] = useState('');

  const handleConfigChange = (e) => {
    setMapConfig(e.target.value);
  };

  return (
    <BaseNode 
      id={id}
      title="Map"
      hasSource={true}
      sourceId={`${id}-mapped`}
      hasTarget={true}
      targetIds={[`${id}-mappedIn`]}
    >
      <div>
        <label>
          Configuration: <br />
          <input 
            type="text" 
            value={mapConfig} 
            onChange={handleConfigChange} 
            className='input-text-style'
          />
        </label>
      </div>
    </BaseNode>
  );
}
