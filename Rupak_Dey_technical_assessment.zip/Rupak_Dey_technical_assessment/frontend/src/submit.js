// submit.js

import { useState } from "react";

export const SubmitButton = ({ pipeline }) => {
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState(null);

    const handleSubmit = async () => {
        setLoading(true);
        try {
            const response = await fetch('http://localhost:8000/pipelines/parse', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(pipeline)
            });

            const data = await response.json();

            if (response.ok) {
                setResult(data);
                alert(`Number of nodes: ${data.num_nodes}, Number of edges: ${data.num_edges}, Is DAG: ${data.is_dag}`);
            } else {
                throw new Error(data.message || 'Error processing the pipeline');
            }
        } catch (error) {
            alert('An error occurred: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <button 
                onClick={handleSubmit} 
                disabled={loading} 
                style={{ 
                    background: 'white',
                    height: '3rem',
                    width: '6rem',
                    borderRadius: '5px',
                    color: '#1C2536',
                    border: '2px solid #8a5df0'
                }}
            >
                {loading ? 'Submitting...' : 'SUBMIT'}
            </button>
        </div>
    );
};
