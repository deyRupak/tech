from fastapi import FastAPI, Request
from pydantic import BaseModel
from typing import List, Dict, Optional
from fastapi.middleware.cors import CORSMiddleware

origins = [
    "http://localhost:3000",
]

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins, 
    allow_credentials=True,
    allow_methods=["*"],  
    allow_headers=["*"], 
)

class NodeData(BaseModel):
    id: str
    type: str
    position: Dict[str, float]
    data: Dict[str, str]
    width: Optional[int] = None  
    height: Optional[int] = None 

class EdgeData(BaseModel):
    id: str
    source: str
    sourceHandle: Optional[str] = None
    target: str
    targetHandle: Optional[str] = None  
    type: Optional[str] = "smoothstep"  
    animated: Optional[bool] = False 
    markerEnd: Optional[Dict[str, str]] = None

class Pipeline(BaseModel):
    nodes: List[NodeData]
    edges: List[EdgeData]


# Root endpoint
@app.get('/')
def read_root():
    return {'Ping': 'Pong'}

# Endpoint to parse the pipeline
@app.post('/pipelines/parse')
async def parse_pipeline(pipeline: Pipeline):
    try:
        num_nodes = len(pipeline.nodes)
        num_edges = len(pipeline.edges)

        is_dag = check_if_dag(pipeline.nodes, pipeline.edges)

        return {
            'num_nodes': num_nodes,
            'num_edges': num_edges,
            'is_dag': is_dag
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Error processing the pipeline")


# Function to check if the graph is a Directed Acyclic Graph
def check_if_dag(nodes, edges):
    # adjacency list for the graph
    adj_list = {node.id: [] for node in nodes}
    for edge in edges:
        adj_list[edge.source].append(edge.target)

    # topological sort to check if the graph has cycles
    in_degree = {node.id: 0 for node in nodes}
    for edge in edges:
        in_degree[edge.target] += 1

    queue = [node.id for node in nodes if in_degree[node.id] == 0]
    sorted_nodes = []

    while queue:
        current_node = queue.pop(0)
        sorted_nodes.append(current_node)

        for neighbor in adj_list[current_node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    return len(sorted_nodes) == len(nodes)